package springboot2.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SuppressWarnings("unchecked")
@SpringBootTest
class SpringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
