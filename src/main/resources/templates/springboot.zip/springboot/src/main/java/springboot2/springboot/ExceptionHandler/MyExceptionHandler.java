package springboot2.springboot.ExceptionHandler;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

//@ControllerAdvice
//public class MyExceptionHandler {
//    @ExceptionHandler(value =Exception.class)
//    public String exceptionHandler(Exception e){
//        System.out.println("异常！原因是:"+e);
//        return e.getMessage();
//    }
//}
